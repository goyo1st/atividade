import { Text, SafeAreaView, StyleSheet } from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import Feather from 'react-native-vector-icons/Feather';


import Home from '../pages/Home/index';
import Contato from '../pages/Contato/index';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          tabBarShowLabel: true,
        }}
      >

      <Tab.Screen
        name="Home"
        component={Home}
        options={{
            tabBarIcons:({color,size}) =>{
              return <Feather name="home" color={'cyan'} size={25}/>;
            },
        }}  
        />

      <Tab.Screen
      name="Contato"
      component={Contato}
      options={{
        tabBarIcon:({color,size}) =>{
          return <Feather name="user"color={'tomato'} size={25}/>
        }
      }}  
      />

    </Tab.Navigator>
    </NavigationContainer>
  );
}


