import { View, Text,} from 'react-native';

export default function Contato(){
 
  return(
    <View>
      <Text>Tela Contato</Text>
     
    </View>    
  )
  
}


