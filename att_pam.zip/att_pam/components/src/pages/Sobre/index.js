import { Image, View, Text, Button } from 'react-native';
import { useNavigation } from '@react-navigation/native';

function Sobre() {
  const navigation = useNavigation();

  return (
    <View>
      <Text
        style={{
          textAlign: 'center',
          alignItems: 'center',
          marginTop: 80,
          fontSize: 27,
          fontWeight: 'bold',
        }}>
        {'Felipe Fogal, um cara animal!!!'}
        {'\n'}
        {'Curiosidades?'}
      </Text>
      <Image
        source={{
          uri: 'https://lh3.googleusercontent.com/a/ACg8ocJlnZ3RSIhDxQyLG_OtQVqfA6S2ildNvOvPmQHDRKL0i4wp1NhdGw=s288-c-no',
        }}
        style={{ width: 200, height: 200, alignSelf: 'center' }}
      />
      <Button
        title="Ir para Contato"
        onPress={() => navigation.navigate('Contato')}
      />
    </View>
  );
}
export default Sobre;
