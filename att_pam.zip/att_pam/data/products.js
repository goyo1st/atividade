export const PRODUCTS = [
  { id: '1', name: 'Notebook Gamer', description: 'Notebook de alta performance para jogos.', price: 4500 },
  { id: '2', name: 'Smartphone Pro', description: 'Celular com câmera de alta resolução.', price: 3200 },
  { id: '3', name: 'Fone Bluetooth', description: 'Fone com cancelamento de ruído.', price: 600 },
];