import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Bem-vindo ao Catálogo de Produtos</Text>
      <Text style={styles.title}>Clique nos botões para navegar!</Text>
      <Button title="Ver Produtos" onPress={() => navigation.navigate('Products')} />
      <Button title="Informações" onPress={() => navigation.navigate('Info')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 22, marginBottom: 20 },
});