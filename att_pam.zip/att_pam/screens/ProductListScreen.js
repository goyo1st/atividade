import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { PRODUCTS } from '../data/products';

export default function ProductListScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <FlatList
        data={PRODUCTS}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            onPress={() => navigation.navigate('ProductDetails', { product: item })}
          >
            <Text style={styles.name}>{item.name}</Text>
            <Text>Preço: R$ {item.price}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  item: { backgroundColor: '#f1f1f1', padding: 12, marginBottom: 10, borderRadius: 5 },
  name: { fontSize: 18, fontWeight: 'bold' },
});