import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function InfoScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Aplicativo de catálogo de produtos criado com React Native.</Text>
      <Text style={styles.text}>Desenvolvido para a aula de PAM.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 16 },
  text: { fontSize: 16, textAlign: 'center', marginBottom: 10 },
});